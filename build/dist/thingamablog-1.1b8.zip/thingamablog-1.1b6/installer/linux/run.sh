#!/bin/sh
cd /opt/thingamablog-@VERSION@
java -jar thingamablog.jar
